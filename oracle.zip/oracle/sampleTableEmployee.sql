create user example identified by example;

grant dba to example;

conn example / example
CREATE TABLE
    employees (
        employee_id NUMBER PRIMARY KEY,
        first_name VARCHAR2 (50),
        last_name VARCHAR2 (50),
        department_id NUMBER,
        job_title VARCHAR2 (50),
        salary NUMBER (10, 2),
        incentive NUMBER (10, 2)
    );

INSERT INTO
    employees
VALUES
    (1, 'John', 'Doe', 10, 'Manager', 60000, NULL);

INSERT INTO
    employees
VALUES
    (2, 'Jane', 'Smith', 20, 'Developer', 50000, NULL);

INSERT INTO
    employees
VALUES
    (3, 'Jim', 'Brown', 10, 'Analyst', 55000, NULL);

INSERT INTO
    employees
VALUES
    (4, 'Jake', 'White', 30, 'Developer', 52000, NULL);

INSERT INTO
    employees
VALUES
    (5, 'Jill', 'Green', 20, 'Tester', 48000, NULL);

INSERT INTO
    employees
VALUES
    (6, 'Jerry', 'Black', 10, 'Manager', 62000, NULL);