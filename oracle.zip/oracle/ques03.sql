-- Program to Check if a Given Number is Positive, Negative, or Zero

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

DECLARE
  v_number NUMBER := &input_number;  -- Use &input_number for input during execution
BEGIN
  IF v_number > 0 THEN
    DBMS_OUTPUT.PUT_LINE('The number is positive.');
  ELSIF v_number < 0 THEN
    DBMS_OUTPUT.PUT_LINE('The number is negative.');
  ELSE
    DBMS_OUTPUT.PUT_LINE('The number is zero.');
  END IF;
END;
/