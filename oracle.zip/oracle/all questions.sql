-- paste these line above for all the question

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;



--  1: Program to Find Number of Rows Affected Using `SQL%ROWCOUNT`**

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    job_title VARCHAR2(50)
);

INSERT INTO employees (employee_id, name, job_title) VALUES (1, 'John Doe', 'Manager');
INSERT INTO employees (employee_id, name, job_title) VALUES (2, 'Jane Smith', 'Developer');
INSERT INTO employees (employee_id, name, job_title) VALUES (3, 'Michael Johnson', 'Analyst');

COMMIT;

DECLARE
    v_rows_updated NUMBER;
BEGIN
    -- Update job titles for testing purposes
    UPDATE employees
    SET job_title = 'Senior ' || job_title
    WHERE job_title = 'Developer';

    -- Retrieve the number of rows affected
    v_rows_updated := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Number of rows updated: ' || v_rows_updated);
END;
/


-- 2: Procedure to Calculate Incentive on Target Achieved and Display Update Message**
CREATE TABLE sales (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    target_achieved NUMBER,
    incentive NUMBER DEFAULT 0
);

INSERT INTO sales (employee_id, name, target_achieved) VALUES (1, 'Alice Brown', 100000);
INSERT INTO sales (employee_id, name, target_achieved) VALUES (2, 'Bob White', 50000);

COMMIT;

CREATE OR REPLACE PROCEDURE calculate_incentive(p_employee_id NUMBER, p_incentive_rate NUMBER) IS
    v_rows_updated NUMBER;
BEGIN
    -- Update incentive based on the target achieved
    UPDATE sales
    SET incentive = target_achieved * p_incentive_rate
    WHERE employee_id = p_employee_id;

    -- Check if the record was updated
    v_rows_updated := SQL%ROWCOUNT;
    IF v_rows_updated > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Incentive updated for employee ID: ' || p_employee_id);
    ELSE
        DBMS_OUTPUT.PUT_LINE('No record found to update for employee ID: ' || p_employee_id);
    END IF;
END;
/

-- Example usage
BEGIN
    calculate_incentive(1, 0.05);  -- Calculate incentive at a 5% rate
END;
/
-- This procedure calculates the incentive for a specified employee based on the achieved target and displays whether the record was updated or not.

---


--  3: Program to Check if a Number is Positive, Negative, or Zero**
DECLARE
    v_number NUMBER := -10;  -- Replace -10 with any number to test
BEGIN
    IF v_number > 0 THEN
        DBMS_OUTPUT.PUT_LINE('The number is positive.');
    ELSIF v_number < 0 THEN
        DBMS_OUTPUT.PUT_LINE('The number is negative.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('The number is zero.');
    END IF;
END;
/



-- 4: Program to Display Job Titles of All Employees with a Heading**

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    job_title VARCHAR2(50)
);

INSERT INTO employees (employee_id, name, job_title) VALUES (1, 'John Doe', 'Manager');
INSERT INTO employees (employee_id, name, job_title) VALUES (2, 'Jane Smith', 'Developer');
INSERT INTO employees (employee_id, name, job_title) VALUES (3, 'Michael Johnson', 'Analyst');

COMMIT;

DECLARE
    CURSOR job_cursor IS
        SELECT job_title FROM employees;
    v_job_title VARCHAR2(50);
BEGIN
    DBMS_OUTPUT.PUT_LINE('Job Titles:');
    DBMS_OUTPUT.PUT_LINE('-----------');
    
    OPEN job_cursor;
    LOOP
        FETCH job_cursor INTO v_job_title;
        EXIT WHEN job_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(v_job_title);
    END LOOP;
    CLOSE job_cursor;
END;
/


--  5: Exercises on `LENGTH()` Function**

DECLARE
    emp_name VARCHAR2(50) := 'John Doe';
    name_length NUMBER;
BEGIN
    -- Using LENGTH function to find the length of emp_name
    name_length := LENGTH(emp_name);
    DBMS_OUTPUT.PUT_LINE('Length of name ' || emp_name || ' is: ' || name_length);
END;
/

--  6: Exercises on `INSTR()` Function**

DECLARE
    emp_name VARCHAR2(50) := 'John Doe';
    position NUMBER;
BEGIN
    -- Using INSTR function to find the position of space in emp_name
    position := INSTR(emp_name, ' ');
    DBMS_OUTPUT.PUT_LINE('Position of space in name ' || emp_name || ' is: ' || position);
END;
/

--  7: Insert Records from One Table to Another**
CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    department VARCHAR2(50)
);

CREATE TABLE employees_backup AS SELECT * FROM employees WHERE 1=0;

-- Sample Data
INSERT INTO employees (employee_id, name, department) VALUES (101, 'Alice', 'HR');
INSERT INTO employees (employee_id, name, department) VALUES (102, 'Bob', 'Finance');
COMMIT;

-- This PL/SQL block copies records from the `employees` table to `employees_backup`.

BEGIN
    INSERT INTO employees_backup
    SELECT * FROM employees;
    DBMS_OUTPUT.PUT_LINE('Records copied to employees_backup.');
END;
/

--  8: Display Details for Employee of ID 149**

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    department VARCHAR2(50),
    salary NUMBER
);

-- Sample Data
INSERT INTO employees (employee_id, name, department, salary) VALUES (149, 'Charlie', 'IT', 75000);
COMMIT;

-- This block fetches details of the employee with ID 149.
DECLARE
    emp_name VARCHAR2(50);
    emp_department VARCHAR2(50);
    emp_salary NUMBER;
BEGIN
    SELECT name, department, salary INTO emp_name, emp_department, emp_salary
    FROM employees
    WHERE employee_id = 149;

    DBMS_OUTPUT.PUT_LINE('Name: ' || emp_name);
    DBMS_OUTPUT.PUT_LINE('Department: ' || emp_department);
    DBMS_OUTPUT.PUT_LINE('Salary: ' || emp_salary);
END;
/


--  9: Create an Explicit Cursor with FOR Loop**

-- This block uses a cursor to retrieve and display employee names and departments.

DECLARE
    CURSOR emp_cursor IS
        SELECT name, department FROM employees;
BEGIN
    FOR emp_record IN emp_cursor LOOP
        DBMS_OUTPUT.PUT_LINE('Name: ' || emp_record.name || ', Department: ' || emp_record.department);
    END LOOP;
END;
/

--  10: Fetch Single Record and Single Column**
DECLARE
    emp_name VARCHAR2(50);
BEGIN
    SELECT name INTO emp_name
    FROM employees
    WHERE employee_id = 101;

    DBMS_OUTPUT.PUT_LINE('Employee Name: ' || emp_name);
END;
/


--  11: Fetch Multiple Records and Columns**
DECLARE
    TYPE emp_record_type IS RECORD (
        name VARCHAR2(50),
        department VARCHAR2(50)
    );
    emp_record emp_record_type;
    CURSOR emp_cursor IS SELECT name, department FROM employees;
BEGIN
    OPEN emp_cursor;
    LOOP
        FETCH emp_cursor INTO emp_record;
        EXIT WHEN emp_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Name: ' || emp_record.name || ', Department: ' || emp_record.department);
    END LOOP;
    CLOSE emp_cursor;
END;
/



-- 12: Display Department, Head, City, and Employee with Highest Salary**

CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50),
    head VARCHAR2(50),
    city VARCHAR2(50)
);

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    department_id NUMBER,
    salary NUMBER,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Sample Data
INSERT INTO departments (department_id, department_name, head, city) VALUES (1, 'HR', 'Alice', 'New York');
INSERT INTO employees (employee_id, name, department_id, salary) VALUES (101, 'Bob', 1, 80000);
INSERT INTO employees (employee_id, name, department_id, salary) VALUES (102, 'Charlie', 1, 85000);
COMMIT;

DECLARE
    dep_name VARCHAR2(50);
    head_name VARCHAR2(50);
    city_name VARCHAR2(50);
    emp_name VARCHAR2(50);
BEGIN
    SELECT d.department_name, d.head, d.city, e.name
    INTO dep_name, head_name, city_name, emp_name
    FROM departments d
    JOIN employees e ON d.department_id = e.department_id
    WHERE e.salary = (SELECT MAX(salary) FROM employees WHERE department_id = d.department_id);

    DBMS_OUTPUT.PUT_LINE('Department: ' || dep_name || ', Head: ' || head_name || ', City: ' || city_name || ', Highest Paid Employee: ' || emp_name);
END;
/


--  13: Display Employee Name and Salary Increment Percentage Based on Experience**

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    experience NUMBER, -- in years
    salary NUMBER
);

-- Sample Data
INSERT INTO employees (employee_id, name, experience, salary) VALUES (101, 'Alice', 5, 50000);
INSERT INTO employees (employee_id, name, experience, salary) VALUES (102, 'Bob', 10, 70000);
COMMIT;

DECLARE
    emp_name VARCHAR2(50);
    experience NUMBER;
    increment_percentage NUMBER;
    CURSOR emp_cursor IS SELECT name, experience FROM employees;
BEGIN
    FOR emp_record IN emp_cursor LOOP
        emp_name := emp_record.name;
        experience := emp_record.experience;

        -- Calculate increment based on experience
        IF experience < 5 THEN
            increment_percentage := 5;
        ELSIF experience BETWEEN 5 AND 10 THEN
            increment_percentage := 10;
        ELSE
            increment_percentage := 15;
        END IF;

        DBMS_OUTPUT.PUT_LINE('Name: ' || emp_name || ', Increment: ' || increment_percentage || '%');
    END LOOP;
END;
/


-- 14. **Division by Zero Exception Handling**

DECLARE
    num1 NUMBER := 10;
    num2 NUMBER := 0;
    result NUMBER;
BEGIN
    -- Attempt to divide num1 by num2
    result := num1 / num2;
    DBMS_OUTPUT.PUT_LINE('Result: ' || result);
EXCEPTION
    WHEN ZERO_DIVIDE THEN
        DBMS_OUTPUT.PUT_LINE('Error: Division by zero occurred.');
END;
/


-- 15. **CASE_NOT_FOUND Exception Handling**
-- In PL/SQL, the `CASE_NOT_FOUND` exception occurs in a `CASE` statement if no `WHEN` clause matches the `CASE` expression and there is no `ELSE` clause.

DECLARE
    grade CHAR(1) := 'F';
    message VARCHAR2(50);
BEGIN
    -- CASE statement with possible CASE_NOT_FOUND exception
    CASE grade
        WHEN 'A' THEN message := 'Excellent';
        WHEN 'B' THEN message := 'Good';
        WHEN 'C' THEN message := 'Average';
        WHEN 'D' THEN message := 'Below Average';
        -- No ELSE clause is provided
    END CASE;
    
    DBMS_OUTPUT.PUT_LINE('Message: ' || message);
EXCEPTION
    WHEN CASE_NOT_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: No matching case found.');
END;
/


-- In this block, if `grade` does not match any `WHEN` condition (e.g., it is set to 'F'), the `CASE_NOT_FOUND` exception is raised. The custom message "Error: No matching case found." is printed.

---

-- 16. **ACCESS_INTO_NULL Exception Handling**

-- In PL/SQL, the `ACCESS_INTO_NULL` exception occurs when attempting to access a field of an uninitialized (NULL) record.


DECLARE
    TYPE EmployeeRec IS RECORD (
        employee_id NUMBER,
        name VARCHAR2(50)
    );
    emp EmployeeRec;
BEGIN
    -- Attempting to access a NULL record field
    DBMS_OUTPUT.PUT_LINE('Employee ID: ' || emp.employee_id);
EXCEPTION
    WHEN ACCESS_INTO_NULL THEN
        DBMS_OUTPUT.PUT_LINE('Error: Attempted to access a NULL record.');
END;
/


-- In this block, the `emp` record is declared but not initialized, so attempting to access `emp.employee_id` raises the `ACCESS_INTO_NULL` exception, and the custom message "Error: Attempted to access a NULL record." is printed.


-- 17: Trigger to Automatically Update 'last_modified' Timestamp on Row Update**

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    position VARCHAR2(50),
    last_modified TIMESTAMP
);

INSERT INTO employees (employee_id, name, position, last_modified) 
VALUES (1, 'John Doe', 'Manager', SYSTIMESTAMP);

INSERT INTO employees (employee_id, name, position, last_modified) 
VALUES (2, 'Jane Smith', 'Developer', SYSTIMESTAMP);

COMMIT;

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

CREATE OR REPLACE TRIGGER trg_update_last_modified
BEFORE UPDATE ON employees
FOR EACH ROW
BEGIN
    :NEW.last_modified := SYSTIMESTAMP;
END;


-- This trigger automatically updates the `last_modified` timestamp column with the current timestamp (`SYSTIMESTAMP`) whenever a row in the `employees` table is updated.


-- 18: Trigger to Enforce Referential Integrity by Preventing Parent Deletion**

CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50)
);

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    department_id NUMBER,
    CONSTRAINT fk_department FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

INSERT INTO departments (department_id, department_name) VALUES (1, 'Human Resources');
INSERT INTO employees (employee_id, name, department_id) VALUES (1, 'Alice Brown', 1);

COMMIT;

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

CREATE OR REPLACE TRIGGER trg_prevent_delete_department
BEFORE DELETE ON departments
FOR EACH ROW
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM employees
    WHERE department_id = :OLD.department_id;

    IF v_count > 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Cannot delete department with existing employees.');
    END IF;
END;


-- This trigger prevents deletion of a department record if there are related employee records in the `employees` table. It raises an exception if the count of child records is greater than zero.

---

19: Trigger to Check for Duplicate Values in a Column**

CREATE TABLE products (
    product_id NUMBER PRIMARY KEY,
    product_name VARCHAR2(50) UNIQUE
);

INSERT INTO products (product_id, product_name) VALUES (1, 'Laptop');
INSERT INTO products (product_id, product_name) VALUES (2, 'Smartphone');

COMMIT;

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

CREATE OR REPLACE TRIGGER trg_check_duplicate_product_name
BEFORE INSERT OR UPDATE ON products
FOR EACH ROW
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM products
    WHERE product_name = :NEW.product_name AND product_id != :NEW.product_id;

    IF v_count > 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Duplicate product name found.');
    END IF;
END;


-- This trigger checks for duplicates in the `product_name` column in the `products` table. It raises an exception if another record with the same `product_name` already exists.

---

 20: Trigger to Validate Stock Availability for Orders**

CREATE TABLE items (
    item_id NUMBER PRIMARY KEY,
    item_name VARCHAR2(50),
    stock_quantity NUMBER
);

CREATE TABLE orders (
    order_id NUMBER PRIMARY KEY,
    item_id NUMBER,
    quantity NUMBER,
    CONSTRAINT fk_item FOREIGN KEY (item_id) REFERENCES items(item_id)
);

INSERT INTO items (item_id, item_name, stock_quantity) VALUES (1, 'Laptop', 10);
INSERT INTO items (item_id, item_name, stock_quantity) VALUES (2, 'Smartphone', 5);

COMMIT;

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

CREATE OR REPLACE TRIGGER trg_validate_stock
BEFORE INSERT ON orders
FOR EACH ROW
DECLARE
    v_stock_quantity NUMBER;
BEGIN
    SELECT stock_quantity INTO v_stock_quantity
    FROM items
    WHERE item_id = :NEW.item_id;

    IF :NEW.quantity > v_stock_quantity THEN
        RAISE_APPLICATION_ERROR(-20003, 'Insufficient stock for the requested item.');
    END IF;
END;


-- This trigger validates the `stock_quantity` in the `items` table before allowing an order to be placed. It raises an exception if the order quantity exceeds the available stock.

---
