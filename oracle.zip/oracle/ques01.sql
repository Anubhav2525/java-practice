-- Program to Find the Number of Rows Affected Using SQL%ROWCOUNT with an Implicit Cursor

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

DECLARE
  v_rows_affected NUMBER;
BEGIN
  -- Example update statement
  UPDATE employees
  SET salary = salary * 1.1
  WHERE department_id = 10;

  -- Get the number of rows affected
  v_rows_affected := SQL%ROWCOUNT;

  DBMS_OUTPUT.PUT_LINE('Number of rows affected: ' || v_rows_affected);
END;
/

-- output
-- Number of rows affected: 3

-- PL/SQL procedure successfully completed.