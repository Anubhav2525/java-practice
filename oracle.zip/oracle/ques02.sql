-- Procedure to Calculate Incentive on Target Achieved and Display Update Status

SET FEEDBACK ON;
SET SERVEROUTPUT ON;
SET VERIFY ON;

CREATE OR REPLACE PROCEDURE calculate_incentive(p_employee_id NUMBER, p_target NUMBER) IS
  v_incentive NUMBER;
  v_updated_rows NUMBER;
BEGIN
  -- Incentive calculation logic (example: incentive is 5% of target)
  v_incentive := p_target * 0.05;

  -- Update the employee record with the calculated incentive
  UPDATE employees
  SET incentive = v_incentive
  WHERE employee_id = p_employee_id;

  -- Check if the record was updated
  v_updated_rows := SQL%ROWCOUNT;

  IF v_updated_rows > 0 THEN
    DBMS_OUTPUT.PUT_LINE('Record updated successfully with incentive: ' || v_incentive);
  ELSE
    DBMS_OUTPUT.PUT_LINE('No record updated.');
  END IF;
END calculate_incentive;
/